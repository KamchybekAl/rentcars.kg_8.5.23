package kg.mega.rentcars_kg.service;

import kg.mega.rentcars_kg.model.Address;
import kg.mega.rentcars_kg.model.dto.AddressDTO;

import java.util.List;

public interface AddressService {
    Address saveAddress (Address address);
    AddressDTO findById(Long id);
    List<AddressDTO>findAll();
    AddressDTO updateAddress (AddressDTO addressDTO);


}
