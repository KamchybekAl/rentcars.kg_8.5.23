package kg.mega.rentcars_kg.model.enums;

public enum CarCategory {
    ECONOMY_STANDART,
    MINIVAN_4x4_SUV,
    BUSINESS_PREMIUM


}
