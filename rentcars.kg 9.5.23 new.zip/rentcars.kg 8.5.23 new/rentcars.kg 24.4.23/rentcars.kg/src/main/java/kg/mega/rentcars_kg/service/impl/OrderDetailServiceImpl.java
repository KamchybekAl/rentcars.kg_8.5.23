package kg.mega.rentcars_kg.service.impl;

import kg.mega.rentcars_kg.mapper.OrderDetailMapper;
import kg.mega.rentcars_kg.model.Discount;
import kg.mega.rentcars_kg.model.OrderDetail;
import kg.mega.rentcars_kg.model.Price;
import kg.mega.rentcars_kg.model.dto.DiscountDTO;
import kg.mega.rentcars_kg.model.dto.OrderDetailDTO;
import kg.mega.rentcars_kg.repository.AddressRepo;
import kg.mega.rentcars_kg.repository.DiscountRepo;
import kg.mega.rentcars_kg.repository.OrderDetailRepo;
import kg.mega.rentcars_kg.service.AddressService;
import kg.mega.rentcars_kg.service.DiscountService;
import kg.mega.rentcars_kg.service.OrderDetailService;
import kg.mega.rentcars_kg.service.PriceService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
@Service
@RequiredArgsConstructor
@Transactional
public class OrderDetailServiceImpl implements OrderDetailService {
    private final OrderDetailRepo orderDetailRepo;
    private final OrderDetailMapper orderDetailMapper;
    private final PriceService priceService;
    private final DiscountService discountService;
    private final AddressRepo addressRepo;
    private final AddressService addressService;
    private final DiscountRepo discountRepo;

    @Override
    public OrderDetailDTO saveOrderDetail(OrderDetailDTO orderDetailDTO) {

        OrderDetail orderDetail = orderDetailMapper.toEntity(orderDetailDTO);
        orderDetail.setOrderedDays(findReservedDays(orderDetail));
        orderDetail.setPriceBeforeDiscount(calculatePriceWithoutDiscount(orderDetail));
        orderDetail.setPriceWithDiscount(calculatePriceWithDiscount(orderDetail,calculatePriceWithoutDiscount(orderDetail)));
        orderDetail.setGetAddress(addressRepo.findById(orderDetailDTO.getGetAddress().getId()).get()); // Как
        // через addressService, т.к через addressRepo нежелателно говорит ?
        orderDetail.setReturnAddress(addressRepo.findById(orderDetailDTO.getReturnAddress().getId()).get());// Как
        // через addressService,т.к через addressRepo нежелателно говорит ?
        OrderDetail save = orderDetailRepo.save(orderDetail);
        return orderDetailMapper.toDto(save);
    }

    private Double calculatePriceWithDiscount(OrderDetail orderDetail, Double priceWithoutDiscount){
        Discount discount = discountService.findDiscountByCar(orderDetail.getCar());
        List<Discount>discTempList = discountRepo.findAll();
        List<Discount>toArrayList = new ArrayList<>();


        return priceWithoutDiscount-(priceWithoutDiscount*(discount.getDiscount()/100));
    }
    private Double calculatePriceWithoutDiscount(OrderDetail orderDetail){
        Price carPricePerDay = priceService.activePriceByCar(orderDetail.getCar());
        Duration duration = Duration.between(orderDetail.getDateTimeFrom(),orderDetail.getDateTimeTo());
        Long daysCont = Math.abs(duration.toDays());
        return carPricePerDay.getPrice()*daysCont;
    }



    @Override
    public OrderDetailDTO findById(Long id) {
        return orderDetailMapper.toDto(orderDetailRepo.findById(id).get());
    }

    @Override
    public List<OrderDetailDTO> findAll() {
        return orderDetailMapper.toDTOList(orderDetailRepo.findAll());
    }
    @Override
    public OrderDetailDTO updateOrderDetail(OrderDetailDTO orderDetailDTO) {
        OrderDetail updateOrderDetail = orderDetailRepo.findById(orderDetailDTO.getId()).get();
//        венуть позже с OrderDetailServiceImpl 8.5.23 текст файл
        return orderDetailMapper.toDto(updateOrderDetail);
    }

    private int findReservedDays(OrderDetail orderDetail) {
        Duration duration = Duration.between(orderDetail.getDateTimeFrom(), orderDetail.getDateTimeTo());
        return (int) duration.toDays();
    }

}