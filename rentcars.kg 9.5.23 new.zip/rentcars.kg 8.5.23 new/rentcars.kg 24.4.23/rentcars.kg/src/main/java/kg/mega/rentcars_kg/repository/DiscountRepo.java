package kg.mega.rentcars_kg.repository;

import kg.mega.rentcars_kg.model.Car;
import kg.mega.rentcars_kg.model.Discount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DiscountRepo extends JpaRepository<Discount,Long> {
    Optional<Discount> findByCar(Car car);
    @Query(value = "select * from tb_discount where car_id = :carId and end_date > now()", nativeQuery = true)
    List<Discount>getActualDiscount(Long carId);
}
